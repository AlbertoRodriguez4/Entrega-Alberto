import { View, Text } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native-safe-area-context'

export default function Favourite() {
  return (
    <SafeAreaView>
      <Text>Favourite</Text>
      <Text>Favourite</Text>
      <Text>Favourite</Text>
    </SafeAreaView>
  )
}